DELETE FROM products
WHERE rating < 3;