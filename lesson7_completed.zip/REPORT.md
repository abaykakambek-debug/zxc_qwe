# Практическая работа — Урок 7: SQLite + Python + SQL

## 1. Создание базы данных

Таблица `products` содержит поля:

- `id INTEGER PRIMARY KEY AUTOINCREMENT` — уникальный идентификатор каждой записи. `PRIMARY KEY` не допускает повторов и `NULL`; `AUTOINCREMENT` автоматически увеличивает ID.
- `name TEXT NOT NULL` — название товара; поле обязательно для заполнения.
- `price REAL NOT NULL CHECK(price >= 0)` — цена; обязательна и не может быть отрицательной.
- `rating REAL CHECK(rating BETWEEN 0 AND 5)` — рейтинг от 0 до 5. Значение может быть пустым (`NULL`).
- `url TEXT NOT NULL UNIQUE` — ссылка на товар; обязательна и должна быть уникальной.

`UNIQUE` запрещает добавлять две записи с одинаковым URL.

## 2. Импорт данных

Команды:
```bash
py main.py init
py main.py import
py main.py list
```

Результат импорта: прочитано **10 строк CSV**, добавлено **9 новых товаров**. В CSV дважды записан товар «Мышь Logitech M185» с одинаковым URL. При импорте используется `INSERT OR IGNORE`, поэтому строка с повторяющимся URL пропускается. В базе осталось 9 уникальных товаров.

## 3. Пять SQL-запросов и результаты

### 1. Самый дешёвый товар
```sql
SELECT id, name, price
FROM products
ORDER BY price ASC, id ASC
LIMIT 1;
```
Результат: **Коврик для мыши — 2 990**.

### 2. Топ-5 товаров по рейтингу
```sql
SELECT name, rating, price
FROM products
ORDER BY rating DESC, price ASC
LIMIT 5;
```
Результат:
1. SSD Kingston 1TB — 4.9 — 42 990
2. Мышь Logitech M185 — 4.8 — 6 990
3. Ноутбук Lenovo IdeaPad — 4.7 — 289 990
4. Наушники JBL Tune — 4.6 — 24 990
5. Клавиатура Redragon — 4.5 — 15 990

### 3. Поиск товара по слову «мышь»
```sql
SELECT name, price
FROM products
WHERE name LIKE '%Мышь%' OR name LIKE '%мышь%'
ORDER BY name;
```
Результат: **Мышь Logitech M185 — 6 990**.

Примечание: в SQLite `LIKE` не всегда корректно игнорирует регистр кириллических букв, поэтому проверяются оба варианта написания.

### 4. Товары дешевле 20 000
```sql
SELECT name, price
FROM products
WHERE price < 20000
ORDER BY price;
```
Результат:
- Коврик для мыши — 2 990
- Мышь Logitech M185 — 6 990
- USB-хаб Baseus — 8 990
- Клавиатура Redragon — 15 990
- Веб-камера Logitech C270 — 19 990

### 5. Поиск повторяющихся URL
```sql
SELECT url, COUNT(*) AS total
FROM products
GROUP BY url
HAVING COUNT(*) > 1;
```
Результат: **пустая таблица**. Повторы не попали в базу, потому что поле `url` имеет ограничение `UNIQUE`, а импорт выполняется через `INSERT OR IGNORE`.

## 4. Python и безопасность

- `sqlite3.connect(DB_PATH)` — подключается к файлу базы данных.
- `connection.cursor()` — создаёт курсор для выполнения SQL-команд и чтения результатов.
- `cursor.execute(query, params)` — выполняет SQL-запрос; параметры передаются отдельно.
- `commit()` — сохраняет изменения транзакции. В проекте используется `with connection:`, который автоматически подтверждает транзакцию при успешном завершении блока.

Безопасный параметризованный запрос:
```python
cursor.execute(
    'SELECT * FROM products WHERE name = ?',
    (user_input,)
)
```
Знак `?` — место для значения. Пользовательский ввод передаётся отдельно от SQL-кода, что помогает защититься от SQL-инъекций.

## 5. Вопрос к ChatGPT: три товара с рейтингом выше остальных и ценой до 30 000

```sql
SELECT name, rating, price
FROM products
WHERE price <= 30000
ORDER BY rating DESC, price ASC
LIMIT 3;
```

Объяснение:
- `SELECT name, rating, price` — выводит название, рейтинг и цену.
- `FROM products` — выбирает данные из таблицы товаров.
- `WHERE price <= 30000` — оставляет товары стоимостью не выше 30 000.
- `ORDER BY rating DESC` — сортирует по рейтингу от большего к меньшему.
- `price ASC` — при одинаковом рейтинге ставит дешевле товар выше.
- `LIMIT 3` — показывает только три записи.

Результат:
1. Мышь Logitech M185 — рейтинг 4.8, цена 6 990
2. Наушники JBL Tune — рейтинг 4.6, цена 24 990
3. Клавиатура Redragon — рейтинг 4.5, цена 15 990

## Вывод

В ходе работы создана база SQLite, импортированы данные из CSV, проверено ограничение уникальности URL и выполнены пять SQL-запросов. Также рассмотрены основные операции Python с SQLite и безопасная передача параметров в запросы.

**Скриншоты:** для полного отчёта откройте `deals.db` в DB Browser for SQLite, выполните запросы из `sql/quest.sql` и сделайте скриншоты вкладок Browse Data и Execute SQL. Скриншоты не включены, поскольку их нужно снять в вашей программе.
